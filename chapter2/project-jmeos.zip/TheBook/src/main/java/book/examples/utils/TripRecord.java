package book.examples.utils;

import java.util.Set; 


abstract class TripRecord implements TRecord{
	
	abstract Set<? extends InstantRecord> unnest();
	
}

