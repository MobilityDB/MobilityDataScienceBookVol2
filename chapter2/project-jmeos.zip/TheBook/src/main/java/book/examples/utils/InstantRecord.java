package book.examples.utils;


abstract public class InstantRecord implements TRecord, Comparable<InstantRecord>{

	abstract public String asCSVLine(char colSeparator);
	
	abstract public String asCSVHeader(char colSeparator);
	
	
	public int compareTo(InstantRecord other) {
		if (getMillisec() < other.getMillisec() )
			return -1;
		if (getMillisec() > other.getMillisec() )
			return 1;
		return getId() - other.getId();
		}

}
