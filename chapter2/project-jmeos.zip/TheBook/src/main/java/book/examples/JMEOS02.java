package book.examples;


import functions.MeosErrorHandler;
import functions.functions; 
import static functions.functions.temporal_num_instants;
import static functions.functions.tpoint_length;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import book.examples.utils.AISReadRecords;
import book.examples.utils.AISRecord;
import book.examples.utils.ShipRecord;


public class JMEOS02 {
  
	
    public static void main(String[] args) throws Exception {
     	
     	 functions.meos_initialize();
         functions.meos_initialize_timezone("UTC");
         functions.meos_initialize_error_handler(new MeosErrorHandler());


    	// read CSV file 
    	// the information are in chronologically ascendant order, not sorted by MMSI.
    	// A hashmap is built for associating each MMSI with all its AIS records.
    	 HashMap<Long, ArrayList<AISRecord>> data = AISReadRecords.readRecords("/data/aisdk-2024-03-04.csv",
    			 List.of(0,1,2,3,4));
 
    	
    	 
    	// Once the total AIS records are read we can calculate 
    	// temporal attributes trip and SOG for each MMSI
     	ArrayList<ShipRecord> tripRecords = new ArrayList<>();

      	for (Map.Entry<Long, ArrayList<AISRecord>> aisRecMMSI : data.entrySet()) {
     		 Long key = aisRecMMSI.getKey();
     		 ArrayList<AISRecord> itsAISRecords = aisRecMMSI.getValue();
     		 
     		 System.out.println("key= " + key);
     		 
     		 ShipRecord auxi = ShipRecord.builder(aisRecMMSI.getKey(), itsAISRecords ) ;
     		 
      		tripRecords.add( auxi );
     		
     	}
        
     	
     	for (ShipRecord trip : tripRecords) {
     		 System.out.printf("Trip %d-> Number of instants: %d, Distance travelled %f%n",
                     trip.getMMSI(), temporal_num_instants(trip.getTrip()), 
                     tpoint_length(trip.getTrip()));
     		 
     		 
     		 System.out.printf(" Simplified Trip by Douglas-Peucker %d-> Number of instants: %d, Distance travelled %f%n%n",
                     trip.getMMSI(), temporal_num_instants(trip.getSimplifiedTrip()), tpoint_length(trip.getSimplifiedTrip()));
 
     	}

     	// 
        functions.meos_finalize();
    }
}