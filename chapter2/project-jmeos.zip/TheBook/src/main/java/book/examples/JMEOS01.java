package book.examples;

import types.basic.tpoint.tgeom.TGeomPointInst;  
import types.temporal.TInterpolation;
import functions.functions;
import jnr.ffi.Memory;
import jnr.ffi.Pointer;
import jnr.ffi.Runtime;
import static functions.functions.temporal_num_instants;
import static functions.functions.tpoint_length;
import static functions.functions.tsequence_make;
import java.util.ArrayList;
import java.util.List;

public class JMEOS01 {
	
	

    public static void main(String[] args) throws Exception {
     	
    	functions.meos_initialize_timezone("UTC");
//      error_handler_fn errorHandlerFn = new error_handler();
//      functions.meos_initialize_error_handler(errorHandlerFn);
    	
    	
    	ArrayList<String> wktData= new ArrayList<>(List.of(
    				"Point(0 0)@2018-01-01 12:00:00",
    	    		"Point(6 0)@2018-01-01 12:00:06",
    	    		"Point(6 6)@2018-01-01 12:00:11",
    	    		"Point(9 9)@2018-01-01 12:00:14"
    			));
    	
    	ArrayList<Pointer> tGeoPointList = new ArrayList<>();
    	for (String aStr : wktData) {
    		// Option 1
    		Pointer aPointer = functions.tgeompoint_in(aStr);
    		tGeoPointList.add(aPointer);
    		
    		// Option 2
    		// Pointer aPointer = new TGeomPointInst(aStr).getInner();
    		// tGeoPointList.add(aPointer);
		}


    	// Construct the trips
    	Runtime runtime = Runtime.getSystemRuntime();
  	  
    	// Allocate memory for array of pointers for trip instants
    	Pointer tripInstantsArray = Memory.allocate(runtime, tGeoPointList.size() * Long.BYTES);
    	for (int i = 0; i < tGeoPointList.size(); i++) {
    	  	tripInstantsArray.putPointer(i * Long.BYTES, tGeoPointList.get(i));
    	}


        // Create the trip sequence 
    	Pointer trip = tsequence_make(tripInstantsArray, tGeoPointList.size(),
                true, true, TInterpolation.LINEAR.getValue(), true);
          
        System.out.printf("  Trip -> Number of instants: %d, Distance travelled %f%n",
                     temporal_num_instants(trip), tpoint_length(trip));
          
        TGeomPointInst k = new TGeomPointInst(trip);
        System.out.printf("  Trip -> Size (Number of instants): %d, Distance travelled %f%n, Bounds: %s",
                   k.num_instants(), k.length(), k.bounding_box_point().toString(10));
        
     
        functions.meos_finalize();
    }
}