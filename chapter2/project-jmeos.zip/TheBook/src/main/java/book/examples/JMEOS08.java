package book.examples;

     
import functions.MeosErrorHandler;    
import functions.functions;
import jnr.ffi.Memory;
import jnr.ffi.Pointer;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import book.examples.utils.BerlinmodSimplifiedTripRecord;
import book.examples.utils.BerlinmodTripRecord;
import book.examples.utils.CSVRecords;
import book.examples.utils.RegionRecord;
import static functions.functions.*;
import jnr.ffi.Runtime;

public class JMEOS08 {
 	
    public static void main(String[] args) throws Exception {
    	
    	 functions.meos_initialize();
         functions.meos_initialize_timezone("UTC");
         functions.meos_initialize_error_handler(new MeosErrorHandler());
     	
    	
         CSVRecords.setSkipHeaderLines(1);  // skip header
        
         ArrayList<BerlinmodTripRecord> dataTrips = 
            	CSVRecords.readRecords("/data/berlinmod_trips.csv",
            	List.of(0,1,2,3,4),
            	BerlinmodTripRecord::builder
      		 );
         
         // calculate dynamically extent of trips 
         Pointer extent = null;  // STBox
     	 for (BerlinmodTripRecord tripRec : dataTrips) {
        		
       		 // Add to spatial-temporal extent
             extent = tspatial_extent_transfn(extent, tripRec.getTrip());
     	 }
     	 
     	   Pointer sorigin = geom_in("SRID=3857;Point(0 0)", -1);

     	Pointer tripSpatialExtent= null;
     	if (extent != null) {
            // only SPATIAL EXTENTS
            tripSpatialExtent= stbox_get_space(extent);
            System.out.println(  stbox_out(tripSpatialExtent, 6) ) ;
            
        }
        
     	Pointer aa=  stbox_get_space_tile(tripSpatialExtent, 5000.0, 5000.0, 0.0, sorigin);
     	Runtime runtime = Runtime.getSystemRuntime();
     	Pointer noTripTilesPtr = Memory.allocate(runtime, Integer.BYTES);
     	Pointer tripTiles = stbox_space_tiles(tripSpatialExtent, 5000.0, 5000.0, 0.0,
                sorigin, true, noTripTilesPtr);
     	int noTripTiles = noTripTilesPtr.getInt(0);
     	 System.out.printf("Created %d spatial tiles %n",
                 noTripTiles);
     	 System.out.println(aa);
     	System.out.println(tripTiles);
     	
 /* 
     	Pointer sorigin = geom_in("SRID=3857;Point(0 0)", -1);
         
         // Get system runtime for memory allocation
         Runtime runtime = Runtime.getSystemRuntime();
         // Create pointer for count (4 bytes for int)
         Pointer noTripTilesPtr = Memory.allocate(runtime, Integer.BYTES);

         Pointer tripTiles = stbox_space_tiles(tripSpatialExtent, 5000.0, 5000.0, 0.0,
                 sorigin, true, noTripTilesPtr);
         int noTripTiles = noTripTilesPtr.getInt(0);

         
         // Compute value-time tiles for speed
         // Speed range: [0, 35) km/h, Time range: [2020-06-01, 2020-06-05)
         Pointer speedExtent = tbox_in("TBox XT([0, 35),[2020-06-01, 2020-06-05))");
         Pointer duration = pg_interval_in("1 day", -1);
         OffsetDateTime torigin = pg_timestamptz_in("2020-06-01", -1);
  
         
         // Use same runtime for second pointer allocation
         Pointer noSpeedTilesPtr = Memory.allocate(runtime, Integer.BYTES);
         Pointer speedTiles = tfloatbox_value_time_tiles(speedExtent, 10.0,
                 duration, 0.0, torigin, noSpeedTilesPtr);
         int noSpeedTiles = noSpeedTilesPtr.getInt(0);

         System.out.printf("Created %d spatial tiles and %d speed tiles%n",
                 noTripTiles, noSpeedTiles);
*/    
        functions.meos_finalize();
    }

}
