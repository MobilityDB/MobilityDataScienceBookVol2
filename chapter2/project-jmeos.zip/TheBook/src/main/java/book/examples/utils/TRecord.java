package book.examples.utils;

public interface TRecord {
	int getId();
	
	long getMillisec();
}
