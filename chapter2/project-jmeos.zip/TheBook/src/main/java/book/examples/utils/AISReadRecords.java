package book.examples.utils;

import com.opencsv.CSVParser;  
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.TreeSet;

public class AISReadRecords {
	
	private static int linesHeaderToSkip= 1;	
	private static char colSeparator= ',';	


	// qtyLines<= 0 means do not skip nothing
	static public void setSkipHeaderLines(int qtyLines) {
		linesHeaderToSkip= qtyLines;
	}
	
	static public void setColSeparator(char aColSeparator) {
		colSeparator= aColSeparator;
	}
	
	
/*	
	public static void main(String[] args) throws CsvValidationException, IOException  {
		String resourcePath= "/ais_instants.csv";
		HashMap<Long, ArrayList<AISRecord>> data = readRecords(resourcePath,   
				List.of(0,1,2,3,4) );
	}
*/	
	
	
	 // Filter
	public static HashMap<Long,  ArrayList<AISRecord>> readRecords(
			String resourcePath, 
			List<Integer> colpositions,
			Predicate<AISRecord> validator	) throws CsvValidationException, IOException  {
		HashMap<Long, ArrayList<AISRecord>> aisRecords = new HashMap<>();
		
		try (InputStream is = AISReadRecords.class.getResourceAsStream(resourcePath);
	         Reader reader = new InputStreamReader(is) ) {
	             if (is == null) {
	                throw new IllegalArgumentException("Resource not found: " + resourcePath);
	             }
    
	    //Build reader instance
         CSVParser csvParser = new CSVParserBuilder()
            .withSeparator(colSeparator)
            .withIgnoreQuotations(true)
            .build();
         
         CSVReaderBuilder csvBuilder = new CSVReaderBuilder(reader).withCSVParser(csvParser);
        
         if (linesHeaderToSkip > 0) {
        	 csvBuilder.withSkipLines(linesHeaderToSkip);
         }
         
         CSVReader csvReader= csvBuilder.withCSVParser(csvParser).build();
        
        	 

        //Read the CSV file line by line
        String[] aLine;
        int total= 0;
        while ((aLine = csvReader.readNext()) != null) {
          if (aLine != null) {
        	  // Only use the cols indicated in colpositions
        	  AISRecord x = AISRecord.builder(aLine, colpositions);
        	  
        	  // If the AISRecord was generates, then use the parametrized lambda fn to filter
        	  if ( x != null &&  (validator == null || validator.test (x) )  ) {
        			  aisRecords.computeIfAbsent(x.getMMSI(), k -> new ArrayList<>()).add(x);
        		  }
         	  // else skip it
        	  total++;
          }
        }
        
        
        // Some ships have repeated timestamps.
        // Keep only the first one, as Timestamps for temporal values must be strictly increasing
        int OK= 0;
        for (Map.Entry<Long, ArrayList<AISRecord>> entry : aisRecords.entrySet()) {
			  Long MMSI = entry.getKey();
			 ArrayList<AISRecord> val = entry.getValue();
			 
			 ArrayList<AISRecord> uniqueList = val.stream()
			            .collect(Collectors.collectingAndThen(
			                Collectors.toCollection(() -> 
			                new TreeSet<>(Comparator.comparing(AISRecord::getMillisec))),
			                ArrayList::new
			            ));
			    
			 aisRecords.put(MMSI, uniqueList);
			 OK+= uniqueList.size();
			
		}

        System.out.println(String.format("Number of lines in the CSV: %d, Number of AIS records being used: %d. %g \\% records are kept ", total, OK, 1.0*OK/total ) );

	 } // end try
	return aisRecords;
	} // end method
	
	

				
	// Without filter	
	public static HashMap<Long,  ArrayList<AISRecord>> readRecords(String resourcePath, List<Integer> colpositions) throws CsvValidationException, IOException  {
		return readRecords( resourcePath, colpositions, null);
	}
	
	
} // end class
