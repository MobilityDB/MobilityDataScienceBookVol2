package book.examples.utils;

import com.opencsv.CSVParser;    
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.TreeSet;

public class AISReadRecords {
	
	private static int linesHeaderToSkip= 1;	
	private static char colSeparator= ',';	


	// qtyLines<= 0 means do not skip nothing
	static public void setSkipHeaderLines(int qtyLines) {
		linesHeaderToSkip= qtyLines;
	}
	
	static public void setColSeparator(char aColSeparator) {
		colSeparator= aColSeparator;
	}
	
	// Without filter	
	public static HashMap<Long,  ArrayList<AISRecord>> readRecords(String absolutePath, List<Integer> colpositions) throws CsvValidationException, IOException  {
		return readRecords( absolutePath, colpositions, null);
	}
	
	
	// Filter
	public static HashMap<Long,  ArrayList<AISRecord>> readRecords(
			String absolutePath, 
			List<Integer> colpositions,
			Predicate<AISRecord> validator	) throws CsvValidationException, IOException  {
		HashMap<Long, ArrayList<AISRecord>> aisRecords = new HashMap<>();
	
		BufferedReader reader = new BufferedReader(new FileReader(absolutePath));

		//Build reader instance
		CSVParser csvParser = new CSVParserBuilder()
			.withSeparator(colSeparator)
            .withIgnoreQuotations(true)
            .build();
         
		CSVReaderBuilder csvBuilder = new CSVReaderBuilder(reader).withCSVParser(csvParser);
        
		if (linesHeaderToSkip > 0) {
			csvBuilder.withSkipLines(linesHeaderToSkip);
		}
         
		CSVReader csvReader= csvBuilder.withCSVParser(csvParser).build();
        
		//Read the CSV file line by line
        String[] aLine;
        int total= 0;
        while ((aLine = csvReader.readNext()) != null) {
           if (aLine != null) {
        	  // Only use the cols indicated in colpositions
        	  AISRecord x = AISRecord.builder(aLine, colpositions);
        	  
        	  // If the AISRecord was generated, then use the parametrized lambda fn to filter
        	  if ( x != null &&  (validator == null || validator.test (x) )  ) {
        			  aisRecords.computeIfAbsent(x.getMMSI(), k -> new ArrayList<>()).add(x);
        		  }
         	  // else skip it
        	  total++;
          }
        }

        
        // Some ships have repeated timestamps.
        // Keep only the first one, as Timestamps for temporal values must be strictly increasing
        int OK= 0;
        for (Map.Entry<Long, ArrayList<AISRecord>> entry : aisRecords.entrySet()) {
			  Long MMSI = entry.getKey();
			 ArrayList<AISRecord> val = entry.getValue();
			 
			 ArrayList<AISRecord> uniqueList = val.stream()
			            .collect(Collectors.collectingAndThen(
			                Collectors.toCollection(() -> 
			                new TreeSet<>(Comparator.comparing(AISRecord::getMillisec))),
			                ArrayList::new
			            ));
			    
			 aisRecords.put(MMSI, uniqueList);
//			 System.out.println("uniquelist: " + uniqueList.size());
			 OK+= uniqueList.size();
			
		}

        System.out.printf("Number of lines in the CSV: %d, Number of AIS records being used: %d. %g %% records are kept\n",
        		total, OK, 100.0*OK/total  );

        return aisRecords;
	} // end method
	
	
	
} // end class
