package book.examples.utils;

import com.opencsv.CSVParser;      
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.Set;
import java.util.TreeSet;

public class CSVRecords {
	private static int linesHeaderToSkip= 1;	
	private static char colSeparator= ',';	


	// qtyLines<= 0 means do not skip nothing
	static public void setSkipHeaderLines(int qtyLines) {
		linesHeaderToSkip= qtyLines;
	}
	
	static public void setColSeparator(char aColSeparator) {
		colSeparator= aColSeparator;
	}

	
	
	// Without filter	
	public static<T> ArrayList<T> readRecords(
				String absolutePath, 
				List<Integer> colpositions, 
				BiFunction<String[], List<Integer>, T> mapper ) throws CsvValidationException, IOException  {
			return readRecords(absolutePath, colpositions, mapper, null);
		}
	
	// With filter	
	public static<T>  ArrayList<T> readRecords(
			String absolutePath, 
			List<Integer> colpositions, 
			BiFunction<String[], List<Integer>, T> mapper,
			Predicate<T> validator	) throws CsvValidationException, IOException  {
	
		ArrayList<T> theTripRecords = new ArrayList<>();
		
		BufferedReader reader = new BufferedReader(new FileReader(absolutePath));
    
		//Build reader instance
		CSVParser csvParser = new CSVParserBuilder()
					.withSeparator(colSeparator)
					.withIgnoreQuotations(true)
					.build();
         
		CSVReaderBuilder csvBuilder = new CSVReaderBuilder(reader).withCSVParser(csvParser);
        
		if (linesHeaderToSkip > 0) {
			csvBuilder.withSkipLines(linesHeaderToSkip);
		}
         
		CSVReader csvReader= csvBuilder.withCSVParser(csvParser).build();
        
        	 

		//Read the CSV file line by line
		String[] aLine;
		int total= 0;
		while ((aLine = csvReader.readNext()) != null) {
			if (aLine != null) {
				// Only use the cols indicated in colpositions
				T x = mapper.apply(aLine, colpositions  );
        	  
				// If the Record was generated, then use the parametrized lambda fn to filter data
				if ( x != null &&  (validator == null || validator.test (x) )  ) {
					theTripRecords.add( x );
				}
				// else skip it
        	  
				total++;
			}
		}

        
		System.out.printf(
				"Number of lines in the CSV: %d, Number of records being used: %d. The %.2f records are kept.%n",
				total, theTripRecords.size(), 100.0*theTripRecords.size()/total  );

		return theTripRecords;
	} // end method
	

		
	public static<T extends TripRecord, I extends InstantRecord> void 
	writeInstantRecords(
			String absolutePath, 
			ArrayList<T> tripsRecords,
			Function<T, Set<I>> unnestMapper
			) 
					throws IOException  {

		// A red black tree to keep a sorted collection of InstantRecords
        Set<I> treeSet = new TreeSet<>();
         
		for (T tripRecord : tripsRecords) {
			 Set<I> x = unnestMapper.apply(tripRecord);
              treeSet.addAll(x);
 		}
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(absolutePath));
		
		
		// Write header
		Iterator<I> it = treeSet.iterator();
		if (it.hasNext()) {
		     I primero = it.next();
		     writer.write(primero.asCSVHeader(colSeparator));
		}
			
		
        // Write all instants
		for (I instantRecord : treeSet) {
			writer.write(instantRecord.asCSVLine(colSeparator) );
		}
		writer.close();

        System.out.printf("%d observation records written in file '%s'%n", treeSet.size(), absolutePath );
    
              		
     }
	

} // end class

