package book.examples.utils;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.postgresql.PGProperty;
import org.postgresql.ds.PGSimpleDataSource;

public class PGDBStore {

	private PGSimpleDataSource ods = new PGSimpleDataSource ();
	private Connection conn;
	
	public PGDBStore() {
		// // host.docker.internal,  localhost, etc
		ods.setProperty(PGProperty.PG_HOST, "host.docker.internal");  
		ods.setProperty(PGProperty.PG_DBNAME, null );
		ods.setProperty(PGProperty.PG_PORT, "6666" );
		ods.setProperty(PGProperty.USER, "postgres");
		ods.setProperty(PGProperty.PASSWORD, "postgres");
	}
	
	public void createDatabase(String dbName) throws SQLException {
		Connection conn = ods.getConnection();
		
		PreparedStatement pstmt;
		// CREATE DATABASE IF NOT EXISTS is not possible in PG
		// Try to create it. If it fails, try to connect to and existing DB
		String strQuery = "CREATE DATABASE " + dbName;
		
		try {
			pstmt = conn.prepareStatement(strQuery);
			pstmt.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			System.out.printf("Trying to connect to %s DB", dbName);
		}
		
		connectToDatabase(dbName);
	}
	
	public void connectToDatabase(String dbName) throws SQLException  {
		ods.setProperty(PGProperty.PG_DBNAME, dbName);
		conn = ods.getConnection();
		
		String strQuery = "CREATE EXTENSION IF NOT EXISTS MobilityDB CASCADE";
		
		PreparedStatement pstmt = conn.prepareStatement(strQuery);
		pstmt.executeUpdate();
	}
	
	
	public void createShipsTable() throws SQLException {
		String strQuery= "DROP TABLE IF EXISTS ships";
		PreparedStatement pstmt = conn.prepareStatement(strQuery);
		pstmt.executeUpdate();
		
		strQuery= "CREATE TABLE ships " +
				"(MMSI integer, trajectory tgeogpoint, SOG tfloat)"; 
		
		pstmt = conn.prepareStatement(strQuery);
		pstmt.executeUpdate();
		System.out.println("CREATING TABLE ships ...");
	}
	
	public void populateShipsTable(ArrayList<ShipRecord> tripRecords) throws SQLException {

		String strQuery= "INSERT INTO ships "
				+ "(MMSI, trajectory, SOG) "
				+ "VALUES (?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(strQuery);
		
		int rows= 0;
		for (ShipRecord shipRecord : tripRecords) {
			

  			pstmt.setLong(1, shipRecord.getMMSI());
			pstmt.setObject(2, shipRecord.getTripAsString(), java.sql.Types.OTHER);
			pstmt.setObject(3, shipRecord.getSOGAsString(), java.sql.Types.OTHER);
				

		// alternatively
/*			String strQuery= String.format("INSERT INTO ships "
					+ "(MMSI, trajectory, SOG) "
					+ "VALUES (%d, '%s', '%s')", 
					shipRecord.getMMSI(),
					shipRecord.getTripAsString(),
					shipRecord.getSOGAsString()
					)
					;
		//	System.out.println(strQuery);
			PreparedStatement pstmt = conn.prepareStatement(strQuery);
*/
			
			rows+= pstmt.executeUpdate();
		}
		System.out.printf("Finished. %d number of tuples inserted.\n", rows);
	}
	
	
}
