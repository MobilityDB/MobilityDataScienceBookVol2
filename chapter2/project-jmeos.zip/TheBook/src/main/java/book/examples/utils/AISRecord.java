package book.examples.utils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AISRecord {
	// default
	private static ZoneOffset aZoneOffset= ZoneOffset.UTC;
	private static String TimestampPattern= "yyyy-MM-dd HH:mm:ss.SSS";
			
	private long MMSI;
	private Timestamp t;
	private double latitude;
	private double longitude;
	private double SOG;
	
	
	static public void setZoneOffset( ZoneOffset aZone) {
		aZoneOffset= aZone; 
	}
	
	static public ZoneOffset getZoneOffset() {
		return aZoneOffset;
	}
	
	static public void setTimestampFormat(String pattern) {
		TimestampPattern= pattern;
	}
	

	
	private AISRecord() {
	}
	
	public static AISRecord builder(String[] aLine, List<Integer> colsPoistions) {
		AISRecord auxi = new AISRecord();
		
		try {
			// specific format?
			String timestampAsString = aLine[colsPoistions.get(0)];
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TimestampPattern);
			LocalDateTime localDateTime = LocalDateTime.from(formatter.parse(timestampAsString));
			auxi.t= Timestamp.valueOf(localDateTime);
			
			
			auxi.MMSI= Long.valueOf(aLine[colsPoistions.get(1)]);
			auxi.latitude= Double.valueOf(aLine[colsPoistions.get(2)]);
			auxi.longitude= Double.valueOf(aLine[colsPoistions.get(3)]);
			auxi.SOG= Double.valueOf(aLine[colsPoistions.get(4)]);
			return auxi;
		}
		catch (Exception e) {
        // System.out.println("Record with invalid values ignored " +  String.join(", ", aLine)  + e);
			return null;
		}
		

	}
	
	
	
	@Override
	public String toString() {
		return String.format("%s %s %s %s %s", t, MMSI, latitude, longitude, SOG);
	}
	

	public Long getMMSI() {
		return MMSI;
	}
	
	public long  getMillisec() {
		return t.getTime();
	}
	
	public double  getLatitude() {
		return latitude;
	}
	
	public double  getLongitude() {
		return longitude;
	}
	
	public double  getSOG() {
		return SOG;
	}
}


